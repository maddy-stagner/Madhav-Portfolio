
# Madhav Sankar Portfolio

This is a modern dark-themed portfolio site for Madhav Sankar.

## 🛠 Features
- Hero section with banner and profile photo
- About and project sections
- Resume download button
- Fully responsive and deployable

## 🚀 Deploying on GitHub Pages
1. Create a new repository (e.g., `madhav-portfolio`)
2. Upload all files from this folder
3. Go to Settings > Pages > Source: `main` branch, `/root` folder
4. Access your site at: `https://<your-username>.github.io/madhav-portfolio/`
